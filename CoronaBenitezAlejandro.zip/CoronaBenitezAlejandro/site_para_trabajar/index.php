<?php
  session_start();
  
  
  require_once('./productos.php');
  require_once('./funciones.php');

  //Aquí puedes inicializar, si procede, la variable de sesión de la cesta
  //La estructura de la cesta puede ser simplemente un array cuyas claves se correspondan a los identificadores de los productos y cuyo valor sea el número de unidades de ese producto en la cesta
  //Puedes sacar el resto de la información cruzando la información de la cesta con el array producto 
  

  //Aquí puedes gestionar los post. Hay dos funcionalidades en la página (dos formularios): add_to_cart, y update_cart_button (actualizar unidades). La manera de sacar los productos de la cesta es poner a 0 el número de unidades que hay en la cesta y pulsar "UPDATE"
  
  if(!isset($_SESSION['cesta'])){
    $_SESSION['cesta'] = array(
      'productos' => array(
      )
    );
  }else{
    if(isset($_POST['add_to_cart'])){
      $clave = array_keys($_POST['add_to_cart']);
      if(count($_SESSION['cesta']['productos']) == 0){
        array_push($_SESSION['cesta']['productos'], array($productos[$clave[0]]['nombre'] => array($productos[$clave[0]]['precio'], 'cantidad' => 1)));
      }else{
        $existe = false;
        $posicion = 0;
        foreach($_SESSION['cesta']['productos'] as $producto){
          foreach($producto as $contenido){
            if($contenido['nombre'] == $productos[$clave[0]]['nombre']){
              $existe = true;
              break;
            }
          }
        }
        if($existe){
          $_SESSION['cesta']['productos'][$productos[$clave[0]][$posicion]['nombre']['cantidad']]++;
        }else{
          array_push($_SESSION['cesta']['productos'], array($productos[$clave[0]]['nombre'] => array($productos[$clave[0]]['precio'], 'cantidad' => 1)));
        }
      }
    }
  }
  
  $the_basket = getBasketMarkup();
  $the_products = getProductosMarkup();
  include('./home.tpl.php'); 
?>
