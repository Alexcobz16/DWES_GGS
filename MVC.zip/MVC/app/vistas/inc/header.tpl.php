<!DOCTYPE html>
<html lang="es"><head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" type="text/css" href="./public/css/estilos.css">
    <title>Gestor de pokemos BETA</title>
</head>
<body>
    <div class="system_messages"><?php echo $mensajes_usuario; ?></div>