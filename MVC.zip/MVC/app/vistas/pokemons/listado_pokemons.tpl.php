<?php include(RUTA_APP.'/vistas/inc/header.tpl.php'); ?>
<h1>Listado de pokemons</h1>
<table>
    <thead>
        <th>Foto</th>    
        <th>Nombre</th>
        <th>Tipo</th>
    </thead>
    <tbody>
        <?php foreach($datos as $clave_pokemon => $valor_pokemon):?>
            <tr>
                <td><img src="<?php echo $valor_pokemon['url_imagen'];?>" ></td>
                <td><a href="./?controlador=pokemon&metodo=ver&id=<?php echo $valor_pokemon['id_pokemon']; ?>"><?php echo $valor_pokemon['nombre'];?></a></td>
                <td><?php echo $valor_pokemon['tipo'];?></td>
            </tr>
         <?php endforeach; ?>
            
            </tbody>
</table>
<?php include(RUTA_APP.'/vistas/inc/footer.tpl.php'); ?>