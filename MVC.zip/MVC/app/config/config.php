<?php

define('RUTA_APP', dirname(dirname(__FILE__)));

//Aquí las credenciales de la BBDD

define('DB_HOST', 'localhost');
define('DB_NAME', 'pokemon');
define('DB_USER', 'root');
define('DB_PASSWORD', '');

