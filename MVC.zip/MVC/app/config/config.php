<?php

//Configuración de ruta a la app
define('RUTA_APP', dirname(dirname(__FILE__)));

//Configuración de acceso a la base de datos. Usamos constantes simplemente para que veáis que tambiés se puede hacer así.
define('DB_HOST', 'localhost');
define('DB_NAME', 'pokemon');
define('DB_USER', 'root');
define('DB_PASSWORD', '');