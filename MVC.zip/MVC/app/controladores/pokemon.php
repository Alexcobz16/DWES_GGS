<?php

class Pokemon{


    public function __construct(){
        //echo 'controlador pokemon cargado';
    }

    public function listar(){
      /*$datos = [
        '2' => [
          'nombre' => 'Pikachu',
          'tipo' => 'eléctrico',
          'url_imagen' => 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/25.png', 
        ],
        '3' => [
          'nombre' => 'Bulbasaur',
          'tipo' => 'hierba',
          'url_imagen' => 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/1.png', 
        ],
      ];*/

      if(is_file(RUTA_APP.'/modelos/pokemon.php')){
        require_once(RUTA_APP.'/modelos/pokemon.php');
        $modelo_pokemon = new ModeloPokemon();
        $datos = $modelo_pokemon->getAllPokemons();
      }else{
        throw new Exception('No se encuentra el modelo.');
      }

      if(is_file(RUTA_APP.'/vistas/pokemons/listado_pokemons.tpl.php')){
        require_once(RUTA_APP.'/vistas/pokemons/listado_pokemons.tpl.php');
      }else{
        throw new Exception('No se encuentra la vista.');
      }
    }

    public function ver($id){

      if(is_file(RUTA_APP.'/modelos/pokemon.php')){
        require_once(RUTA_APP.'/modelos/pokemon.php');
        $modelo_pokemon = new ModeloPokemon();
        $datos = $modelo_pokemon->getPokemon($id);
      }else{
        throw new Exception('No se encuentra el modelo.');
      }

      if(is_file(RUTA_APP.'/vistas/pokemons/listado_pokemons.tpl.php')){
        require_once(RUTA_APP.'/vistas/pokemons/listado_pokemons.tpl.php');
      }else{
        throw new Exception('No se encuentra la vista.');
      }
    }

  }

