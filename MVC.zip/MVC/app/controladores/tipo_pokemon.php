<?php

class TipoPokemon{


    public function __construct(){
        echo 'controlador tipo pokemon cargado';
    }
}