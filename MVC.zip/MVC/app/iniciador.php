<?php

  require_once('./app/config/config.php');
  require_once('./app/core.php');
  try{
    $iniciador = new Core();
  }catch(Exception $e){
    header('HTTP/1.0 404 Not found');
    die($e->getMessage());
    //require_once(RUTA_APP.'/vistas/404.html');
  }