<?php

Class ModeloPokemon{
    
    private $host = DB_HOST;
    private $db_name =  DB_NAME;
    private $db_user = DB_USER;
    private $db_password = DB_PASSWORD;

    private $conection_handler;

    public function __construct(){
        $dsn = 'mysql:host='.$this->host.';dbname='.$this->db_name;
        $opts = array(
            PDO::ATTR_PERSISTENT => true,
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        );
        $this->conection_handler = new PDO($dsn,$this->db_user,$this->db_password, $opts);
        //$this->conection_hanlder->exec('set names utf8');

    }

    public function getAllPokemons(){
        $resultado = $this->conection_handler->query('SELECT pokemons.id_pokemon, pokemons.nombre, tipos.nombre AS tipo, pokemons.url_imagen FROM pokemons INNER JOIN tipos ON pokemons.tipo = tipos.id_tipo')->fetchAll(PDO::FETCH_ASSOC);
        //VAMOS POR AQUÍ: VER LOS DATOS

        return $resultado;
    }

    public function getPokemon($id){
        $resultado = $this->conection_handler->query("SELECT pokemons.id_pokemon, pokemons.nombre, tipos.nombre AS tipo, pokemons.url_imagen FROM pokemons INNER JOIN tipos ON pokemons.tipo = tipos.id_tipo WHERE pokemons.id_pokemon = " . $id['id'])->fetchAll(PDO::FETCH_ASSOC);
        return $resultado;
    }
}
